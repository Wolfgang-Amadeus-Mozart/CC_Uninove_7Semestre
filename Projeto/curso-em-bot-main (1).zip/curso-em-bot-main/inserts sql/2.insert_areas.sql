INSERT INTO tb_conversation_areas_ctg (name, created_at)
VALUES('Front-End', DATE('now')),
    ('Back-End', DATE('now')),
    ('Mobile', DATE('now')),
    ('Git e GitHub', DATE('now')),
    ('Redes de computadores', DATE('now')),
    ('Criação de automação de testes', DATE('now')),
    ('Banco de dados', DATE('now'));