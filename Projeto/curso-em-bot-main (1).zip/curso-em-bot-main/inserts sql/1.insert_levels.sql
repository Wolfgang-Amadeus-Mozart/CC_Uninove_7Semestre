INSERT INTO tb_conversation_level_ctg (name, created_at)
VALUES('Iniciante', DATE('now')),
    ('Intermediário', DATE('now')),
    ('Avançado', DATE('now'));